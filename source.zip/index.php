<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a99cbefdf2             |
    |_______________________________________|
*/
 use Pmpr\Module\Ticket\Ticket; Ticket::symcgieuakksimmu();
