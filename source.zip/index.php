<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f43aa826bcb             |
    |_______________________________________|
*/
 use Pmpr\Module\Ticket\Ticket; Ticket::symcgieuakksimmu();
