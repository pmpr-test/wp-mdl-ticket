<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc0b812328             |
    |_______________________________________|
*/
 use Pmpr\Module\Ticket\Ticket; Ticket::symcgieuakksimmu();
