<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ecd0d8f6e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\REST; use Pmpr\Common\Foundation\REST\RESTController; abstract class Common extends RESTController { public function __construct() { parent::__construct(); $this->namespace .= "\x2f\x74\151\143\153\x65\x74"; } }
