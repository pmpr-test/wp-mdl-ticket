<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a99cbefdf2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\REST; use Pmpr\Common\Foundation\REST\RESTController; abstract class Common extends RESTController { public function __construct() { parent::__construct(); $this->namespace .= "\57\164\151\143\x6b\145\164"; } }
