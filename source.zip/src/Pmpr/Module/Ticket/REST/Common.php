<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7d29d8a1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\REST; use Pmpr\Common\Foundation\REST\RESTController; abstract class Common extends RESTController { public function __construct() { parent::__construct(); $this->namespace .= "\57\x74\x69\x63\x6b\x65\164"; } }
