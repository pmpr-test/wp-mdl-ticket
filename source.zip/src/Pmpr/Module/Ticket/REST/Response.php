<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ecd0d8f6e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\REST; use Pmpr\Common\Foundation\Interfaces\Constants; class Response extends Common { public function __construct() { $this->rest_base = Constants::imqkacyywmmamsqm; parent::__construct(); } }
