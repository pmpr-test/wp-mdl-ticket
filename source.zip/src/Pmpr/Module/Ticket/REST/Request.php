<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b724cc9c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\REST; use Pmpr\Common\Foundation\Interfaces\Constants; class Request extends Common { public function __construct() { $this->rest_base = Constants::qgeesceacsmeqacu; parent::__construct(); } }
