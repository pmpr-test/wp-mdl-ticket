<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46fc56dba             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\REST; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Ticket\Traits\SubmissionTrait; class Ticket extends Common { use SubmissionTrait; public function __construct() { $this->rest_base = Constants::yeaekcacwwyyqigq; parent::__construct(); } }
