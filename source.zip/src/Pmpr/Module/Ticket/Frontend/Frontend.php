<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705179f5c202             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Frontend; use Pmpr\Module\Ticket\Ticket; class Frontend extends Common { public function mameiwsayuyquoeq() { Form::symcgieuakksimmu(); if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq(Ajax::wiysygukkaksueso)) { goto kymkucucyeoeikim; } Ajax::symcgieuakksimmu(); kymkucucyeoeikim: } public function wigskegsqequoeks() { $this->waqewsckuayqguos(Ticket::uuqoeigueqguouek . "\162\x65\156\x64\145\x72\137\x66\162\x6f\x6e\x74\145\x6e\x64\137\143\x6f\156\166\145\x72\x73\x61\164\151\157\x6e", [$this, "\155\153\145\145\157\163\151\151\155\x67\x6f\x79\151\x61\x79\157"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
