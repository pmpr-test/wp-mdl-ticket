<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8a978e6e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Frontend; use Pmpr\Module\Ticket\Ticket; class Frontend extends Common { public function mameiwsayuyquoeq() { Form::symcgieuakksimmu(); if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto umgaesggesswoaqe; } Ajax::symcgieuakksimmu(); umgaesggesswoaqe: } public function wigskegsqequoeks() { $this->waqewsckuayqguos(Ticket::uuqoeigueqguouek . "\162\x65\156\x64\x65\x72\x5f\x66\162\x6f\156\164\x65\x6e\144\x5f\143\157\156\x76\x65\162\x73\141\x74\x69\157\x6e", [$this, "\155\153\x65\145\157\x73\x69\x69\x6d\x67\157\x79\151\x61\171\157"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
