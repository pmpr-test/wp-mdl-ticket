<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f4310c2c816             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Frontend; use Pmpr\Module\Ticket\Ticket; class Frontend extends Common { public function mameiwsayuyquoeq() { Form::symcgieuakksimmu(); if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto uqqaiagaeqgqgaiy; } Ajax::symcgieuakksimmu(); uqqaiagaeqgqgaiy: } public function wigskegsqequoeks() { $this->waqewsckuayqguos(Ticket::uuqoeigueqguouek . "\162\145\156\144\145\x72\137\146\x72\x6f\x6e\164\145\x6e\144\137\143\157\x6e\x76\x65\162\x73\x61\164\x69\157\156", [$this, "\x6d\x6b\145\x65\157\163\x69\151\x6d\x67\x6f\x79\151\x61\x79\157"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
