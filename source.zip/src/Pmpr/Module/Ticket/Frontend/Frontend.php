<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7d29d8a1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Frontend; use Pmpr\Module\Ticket\Ticket; class Frontend extends Common { public function mameiwsayuyquoeq() { Form::symcgieuakksimmu(); if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto umgaesggesswoaqe; } Ajax::symcgieuakksimmu(); umgaesggesswoaqe: } public function wigskegsqequoeks() { $this->waqewsckuayqguos(Ticket::uuqoeigueqguouek . "\162\145\x6e\x64\145\x72\x5f\146\162\x6f\x6e\x74\145\156\144\x5f\143\x6f\156\166\x65\162\163\141\x74\x69\157\156", [$this, "\155\x6b\x65\145\x6f\x73\x69\151\x6d\147\x6f\171\x69\x61\171\x6f"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
