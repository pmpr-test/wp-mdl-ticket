<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f43aa826bcb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Frontend; use Pmpr\Module\Ticket\Ticket; class Frontend extends Common { public function mameiwsayuyquoeq() { Form::symcgieuakksimmu(); if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq()) { goto uqqaiagaeqgqgaiy; } Ajax::symcgieuakksimmu(); uqqaiagaeqgqgaiy: } public function wigskegsqequoeks() { $this->waqewsckuayqguos(Ticket::uuqoeigueqguouek . "\x72\145\x6e\144\145\162\x5f\146\162\x6f\x6e\164\145\156\144\x5f\143\x6f\x6e\166\145\162\x73\141\164\151\x6f\x6e", [$this, "\155\x6b\x65\145\157\x73\151\x69\x6d\147\157\x79\x69\141\171\157"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
