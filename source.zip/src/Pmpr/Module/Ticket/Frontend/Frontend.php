<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc5c3d335c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Frontend; use Pmpr\Module\Ticket\Ticket; class Frontend extends Common { public function mameiwsayuyquoeq() { Form::symcgieuakksimmu(); if ($this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq(Ajax::wiysygukkaksueso)) { Ajax::symcgieuakksimmu(); } } public function wigskegsqequoeks() { $this->waqewsckuayqguos(Ticket::uuqoeigueqguouek . "\x72\145\156\x64\145\162\x5f\x66\x72\x6f\x6e\x74\x65\x6e\144\137\143\157\x6e\166\145\162\x73\141\164\151\157\156", [$this, "\155\x6b\x65\x65\x6f\x73\x69\x69\155\x67\x6f\x79\151\141\171\x6f"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
