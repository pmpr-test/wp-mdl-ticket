<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8a978e6e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Frontend; use Pmpr\Module\Ticket\Container; abstract class Common extends Container { public function umqeyekmoagusaiq($igqsaukqcqscimok) : string { return $this->iuygowkemiiwqmiw("\143\157\156\166\x65\162\163\141\164\x69\157\156\57\151\x74\x65\x6d", (array) $igqsaukqcqscimok); } }
