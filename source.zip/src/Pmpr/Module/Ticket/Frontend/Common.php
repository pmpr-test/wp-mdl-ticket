<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc5c3d335c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Frontend; use Pmpr\Module\Ticket\Container; abstract class Common extends Container { public function umqeyekmoagusaiq($igqsaukqcqscimok) : string { return $this->iuygowkemiiwqmiw("\x63\157\156\x76\145\x72\163\x61\x74\x69\157\x6e\x2f\151\x74\145\x6d", (array) $igqsaukqcqscimok); } }
