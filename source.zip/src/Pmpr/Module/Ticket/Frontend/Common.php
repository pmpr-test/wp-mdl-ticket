<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b724cc9c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Frontend; use Pmpr\Module\Ticket\Container; abstract class Common extends Container { public function umqeyekmoagusaiq($igqsaukqcqscimok) : string { return $this->iuygowkemiiwqmiw("\143\157\x6e\x76\x65\x72\x73\x61\x74\x69\x6f\156\x2f\151\x74\145\x6d", (array) $igqsaukqcqscimok); } }
