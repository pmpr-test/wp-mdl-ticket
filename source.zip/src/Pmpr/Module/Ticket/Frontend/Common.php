<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6800fbf88cf7a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Frontend; use Pmpr\Module\Ticket\Container; abstract class Common extends Container { public function umqeyekmoagusaiq($igqsaukqcqscimok) : string { return $this->iuygowkemiiwqmiw('conversation/item', (array) $igqsaukqcqscimok); } }
