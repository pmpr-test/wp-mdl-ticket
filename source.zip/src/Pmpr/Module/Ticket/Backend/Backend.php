<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f43aa826bcb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Backend; use Pmpr\Module\Ticket\Ticket as Initiator; class Backend extends Common { public function mameiwsayuyquoeq() { $mumyimcwkaemyyue = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if (!$mumyimcwkaemyyue->mcgoysmkqsqooceq()) { goto kecwuwwcwokuksyq; } Ajax::symcgieuakksimmu(); kecwuwwcwokuksyq: } public function wigskegsqequoeks() { $this->waqewsckuayqguos(Initiator::uuqoeigueqguouek . "\x72\145\156\144\x65\x72\137\x62\141\x63\153\145\156\x64\137\x63\157\156\166\x65\x72\163\141\x74\x69\x6f\x6e", [$this, "\x6d\x6b\145\145\157\163\151\151\155\147\x6f\171\151\141\x79\x6f"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
