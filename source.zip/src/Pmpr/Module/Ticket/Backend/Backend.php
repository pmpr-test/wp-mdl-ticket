<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7d29d8a1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Backend; use Pmpr\Module\Ticket\Ticket as Initiator; class Backend extends Common { public function mameiwsayuyquoeq() { $mumyimcwkaemyyue = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if (!$mumyimcwkaemyyue->mcgoysmkqsqooceq()) { goto ickcmqoiosquugwe; } Ajax::symcgieuakksimmu(); ickcmqoiosquugwe: } public function wigskegsqequoeks() { $this->waqewsckuayqguos(Initiator::uuqoeigueqguouek . "\x72\x65\156\x64\x65\x72\137\x62\x61\x63\153\145\156\144\137\143\157\x6e\x76\x65\x72\163\x61\x74\x69\x6f\x6e", [$this, "\155\153\145\x65\x6f\x73\x69\x69\155\147\157\171\x69\x61\x79\x6f"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
