<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705179f5c202             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Backend; use Pmpr\Module\Ticket\Ticket as Initiator; class Backend extends Common { public function mameiwsayuyquoeq() { if (!$this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq(Ajax::wiysygukkaksueso)) { goto wcesymwqykqoyuqk; } Ajax::symcgieuakksimmu(); wcesymwqykqoyuqk: } public function wigskegsqequoeks() { $this->waqewsckuayqguos(Initiator::uuqoeigueqguouek . "\x72\x65\156\144\x65\162\137\142\141\x63\x6b\x65\156\x64\137\143\x6f\156\166\x65\162\163\141\x74\151\x6f\156", [$this, "\155\x6b\145\145\157\163\151\x69\155\147\157\x79\151\x61\171\157"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
