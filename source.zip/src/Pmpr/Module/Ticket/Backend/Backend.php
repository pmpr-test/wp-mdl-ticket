<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8a978e6e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Backend; use Pmpr\Module\Ticket\Ticket as Initiator; class Backend extends Common { public function mameiwsayuyquoeq() { $mumyimcwkaemyyue = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if (!$mumyimcwkaemyyue->mcgoysmkqsqooceq()) { goto ickcmqoiosquugwe; } Ajax::symcgieuakksimmu(); ickcmqoiosquugwe: } public function wigskegsqequoeks() { $this->waqewsckuayqguos(Initiator::uuqoeigueqguouek . "\162\x65\156\144\145\x72\137\142\141\x63\x6b\145\156\144\137\x63\157\156\166\145\x72\163\x61\x74\151\157\x6e", [$this, "\155\x6b\145\145\x6f\163\151\x69\155\147\157\x79\151\141\x79\157"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
