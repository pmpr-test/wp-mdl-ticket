<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc5c3d335c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Backend; use Pmpr\Module\Ticket\Ticket as Initiator; class Backend extends Common { public function mameiwsayuyquoeq() { if ($this->caokeucsksukesyo()->owicscwgeuqcqaig()->mcgoysmkqsqooceq(Ajax::wiysygukkaksueso)) { Ajax::symcgieuakksimmu(); } } public function wigskegsqequoeks() { $this->waqewsckuayqguos(Initiator::uuqoeigueqguouek . "\x72\145\x6e\x64\145\x72\137\142\x61\143\153\145\x6e\x64\137\x63\x6f\156\166\x65\162\163\141\164\x69\x6f\156", [$this, "\155\153\145\145\157\x73\x69\x69\155\x67\157\171\x69\141\171\x6f"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
