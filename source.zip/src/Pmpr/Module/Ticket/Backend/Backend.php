<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ecd0d8f6e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Backend; use Pmpr\Module\Ticket\Ticket as Initiator; class Backend extends Common { public function mameiwsayuyquoeq() { $mumyimcwkaemyyue = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if (!$mumyimcwkaemyyue->mcgoysmkqsqooceq()) { goto ickcmqoiosquugwe; } Ajax::symcgieuakksimmu(); ickcmqoiosquugwe: } public function wigskegsqequoeks() { $this->waqewsckuayqguos(Initiator::uuqoeigueqguouek . "\162\x65\x6e\x64\x65\162\x5f\x62\x61\143\153\x65\156\x64\x5f\143\x6f\x6e\x76\145\x72\163\141\x74\x69\157\156", [$this, "\x6d\x6b\145\x65\157\163\151\x69\155\147\x6f\x79\151\x61\x79\157"]); } public function mkeeosiimgoyiayo($igqsaukqcqscimok) { echo $this->umqeyekmoagusaiq($igqsaukqcqscimok); } }
