<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46fc56dba             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Panel; use Pmpr\Module\Panel\REST\AbstractREST; class Controller extends AbstractREST { }
