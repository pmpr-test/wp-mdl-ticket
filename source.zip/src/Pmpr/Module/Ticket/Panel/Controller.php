<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678aa12481766             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Panel; use Pmpr\Module\Panel\REST\AbstractREST; class Controller extends AbstractREST { }
