<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705179f5c202             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Panel; use Pmpr\Module\Panel\REST\AbstractREST; class Controller extends AbstractREST { }
