<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705dd00337c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Panel; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Panel\AbstractPanel; class Panel extends AbstractPanel { public function __construct() { $this->name = Constants::yeaekcacwwyyqigq; parent::__construct(); } public function gigwcakmiyayoigw() { $this->ogyceaekywowkqsc(Controller::symcgieuakksimmu()); } public function sqwgomwcqysewuks() : array { return []; } public function yaegyqkcqwowauga() : array { return []; } }
