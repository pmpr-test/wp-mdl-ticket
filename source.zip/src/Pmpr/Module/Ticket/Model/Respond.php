<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705179f5c202             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Respond extends Common { public function register() { $this->saemoowcasogykak(IconInterface::osaqwqwkkmocawgs)->guiaswksukmgageq(__("\122\145\x73\160\x6f\156\144", PR__MDL__TICKET))->muuwuqssqkaieqge(__("\x52\x65\163\160\157\156\144\x73", PR__MDL__TICKET)); } public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->qoemykoeuecmsmwe(Constants::ckmsuwamgymouaeu)->acceqyqygswoecwe(8)->gswweykyogmsyawy(__("\x52\x65\x73\x70\x6f\156\144\145\x72", PR__MDL__TICKET)))->cquokmemekqqywgi($eqwoegegiamegqsm->eoaomaokwkwqyqiq(self::asywgyemkouimocw)->gswweykyogmsyawy(__("\124\151\143\x6b\145\x74", PR__MDL__TICKET))->wuuqgaekqeymecag(Ticket::class)->eewuieiqoqmekwmw(Constants::sayycgcceusuyycg))->cquokmemekqqywgi($eqwoegegiamegqsm->eoaomaokwkwqyqiq(Ticket::miwkyequoaigisoa)->gswweykyogmsyawy(__("\122\x65\163\160\x6f\x6e\163\145", PR__MDL__TICKET))->wuuqgaekqeymecag(Response::class)); parent::uwmqacgewuauagai(); } }
