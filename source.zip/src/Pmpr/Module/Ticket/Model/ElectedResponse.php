<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f43aa826bcb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class ElectedResponse extends Common { const miwkyequoaigisoa = Constants::imqkacyywmmamsqm . Constants::mswocgcucqoaesaa; public $timestamps = false; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->yioesawwewqaigow(IconInterface::osaqwqwkkmocawgs)->guiaswksukmgageq(__("\x45\x6c\x65\143\164\x65\x64\x20\x52\145\x73\160\157\x6e\x73\145", PR__MDL__TICKET))->muuwuqssqkaieqge(__("\105\154\x65\x63\x74\145\x64\40\122\145\163\x70\157\156\163\x65\163", PR__MDL__TICKET))->gemkqqguesukeocw()->aseucqksocwomwos()->wkesqcmiekqoykag()->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(Constants::qescuiwgsyuikume)->gswweykyogmsyawy(__("\124\151\164\154\145", PR__MDL__TICKET)))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::miwkyequoaigisoa)->gswweykyogmsyawy(__("\x52\x65\x73\x70\x6f\156\163\x65", PR__MDL__TICKET))->geimymogiqyssawi(Response::class)->wakqsiacyacmumuw()); parent::ewaqwooqoqmcoomi(); } }
