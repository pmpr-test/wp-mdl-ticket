<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8a978e6e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class ElectedResponse extends Common { const miwkyequoaigisoa = Constants::imqkacyywmmamsqm . Constants::mswocgcucqoaesaa; public $timestamps = false; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->yioesawwewqaigow(IconInterface::osaqwqwkkmocawgs)->guiaswksukmgageq(__("\x45\154\145\143\x74\145\x64\x20\122\x65\163\x70\x6f\156\163\145", PR__MDL__TICKET))->muuwuqssqkaieqge(__("\105\154\145\143\164\x65\x64\40\122\x65\x73\x70\157\156\163\x65\163", PR__MDL__TICKET))->gemkqqguesukeocw()->aseucqksocwomwos()->wkesqcmiekqoykag()->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(Constants::qescuiwgsyuikume)->gswweykyogmsyawy(__("\124\x69\x74\x6c\x65", PR__MDL__TICKET)))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::miwkyequoaigisoa)->gswweykyogmsyawy(__("\x52\x65\x73\x70\157\156\x73\x65", PR__MDL__TICKET))->geimymogiqyssawi(Response::class)->wakqsiacyacmumuw()); parent::ewaqwooqoqmcoomi(); } }
