<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ecd0d8f6e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class ElectedResponse extends Common { const miwkyequoaigisoa = Constants::imqkacyywmmamsqm . Constants::mswocgcucqoaesaa; public $timestamps = false; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->yioesawwewqaigow(IconInterface::osaqwqwkkmocawgs)->guiaswksukmgageq(__("\105\x6c\x65\143\164\145\144\x20\122\145\x73\x70\157\156\x73\145", PR__MDL__TICKET))->muuwuqssqkaieqge(__("\x45\x6c\145\143\164\145\144\x20\x52\x65\163\x70\157\156\163\145\x73", PR__MDL__TICKET))->gemkqqguesukeocw()->aseucqksocwomwos()->wkesqcmiekqoykag()->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->cquokmemekqqywgi($this->gysoeyaguiyewoes(Constants::qescuiwgsyuikume)->gswweykyogmsyawy(__("\x54\151\x74\x6c\x65", PR__MDL__TICKET)))->cquokmemekqqywgi($this->eoaomaokwkwqyqiq(self::miwkyequoaigisoa)->gswweykyogmsyawy(__("\x52\x65\163\x70\157\x6e\x73\x65", PR__MDL__TICKET))->geimymogiqyssawi(Response::class)->wakqsiacyacmumuw()); parent::ewaqwooqoqmcoomi(); } }
