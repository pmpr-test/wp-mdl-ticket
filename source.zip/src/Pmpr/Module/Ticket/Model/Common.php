<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705179f5c202             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Ticket\Ticket as Initiator; abstract class Common extends Model { const asywgyemkouimocw = Initiator::uuqoeigueqguouek . Constants::gouqcwikiiygyasc; }
