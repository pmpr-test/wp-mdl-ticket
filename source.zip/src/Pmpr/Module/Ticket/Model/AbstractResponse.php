<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc0b812328             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\ORM\Model; abstract class AbstractResponse extends Model { const asywgyemkouimocw = Constants::yeaekcacwwyyqigq . Constants::mswocgcucqoaesaa; public function register() { $this->esoauokkgywesoku(Constants::cqycgsyykemiygou, __("\101\x74\164\141\143\150\155\145\x6e\164", PR__CMN__FOUNDATION)); } public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->gysoeyaguiyewoes(Constants::TEXT)->gswweykyogmsyawy(__("\x54\x65\x78\x74", PR__MDL__TICKET)))->cquokmemekqqywgi($eqwoegegiamegqsm->qwwuoqeeiyuoyogs(Constants::CREATED_AT)->gswweykyogmsyawy(__("\x43\x72\x65\141\164\145\144\x20\101\164", PR__MDL__TICKET))->qcqeqimisiisswky()); parent::uwmqacgewuauagai(); } }
