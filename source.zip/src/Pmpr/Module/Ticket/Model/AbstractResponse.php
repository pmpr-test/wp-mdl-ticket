<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b724cc9c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\ORM\Model; abstract class AbstractResponse extends Model { const asywgyemkouimocw = Constants::yeaekcacwwyyqigq . Constants::mswocgcucqoaesaa; public function register() { $this->esoauokkgywesoku(Constants::cqycgsyykemiygou, __("\101\164\x74\141\143\150\155\x65\156\164", PR__CMN__FOUNDATION)); } public function uwmqacgewuauagai() { $eqwoegegiamegqsm = $this->caokeucsksukesyo()->skckwsgymkimyuwo(); $this->cquokmemekqqywgi($eqwoegegiamegqsm->gysoeyaguiyewoes(Constants::TEXT)->gswweykyogmsyawy(__("\x54\145\170\x74", PR__MDL__TICKET)))->cquokmemekqqywgi($eqwoegegiamegqsm->qwwuoqeeiyuoyogs(Constants::CREATED_AT)->gswweykyogmsyawy(__("\x43\x72\x65\x61\164\x65\144\x20\x41\x74", PR__MDL__TICKET))->qcqeqimisiisswky()); parent::uwmqacgewuauagai(); } }
