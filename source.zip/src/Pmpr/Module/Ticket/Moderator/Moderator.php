<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             680106a879f76             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Moderator; use Pmpr\Common\Foundation\Traits\InstanceTrait; class Moderator { use InstanceTrait; public final function wqmkwyeuqimyiiaw() : Ticket { return $this->ggmimykuacwcogaq(Ticket::class); } public final function eykosmsuqcyueagm() : Response { return $this->ggmimykuacwcogaq(Response::class); } public final function yyqgamuwwakgciey() : Request { return $this->ggmimykuacwcogaq(Request::class); } }
