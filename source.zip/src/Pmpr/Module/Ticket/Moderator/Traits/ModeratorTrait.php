<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f43aa826bcb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Moderator\Traits; use Pmpr\Module\Ticket\Moderator\Moderator; trait ModeratorTrait { protected ?Moderator $moderator = null; public function xowuwmoiekgcwiaq() : Moderator { if ($this->moderator) { goto cewmoqyysgsmuiya; } $this->moderator = new Moderator(); cewmoqyysgsmuiya: return $this->moderator; } }
