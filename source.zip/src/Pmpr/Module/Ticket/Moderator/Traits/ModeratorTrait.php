<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8a978e6e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Ticket\Moderator\Traits; use Pmpr\Module\Ticket\Moderator\Moderator; trait ModeratorTrait { protected ?Moderator $moderator = null; public function xowuwmoiekgcwiaq() : Moderator { if ($this->moderator) { goto eequksumcoogyoem; } $this->moderator = new Moderator(); eequksumcoogyoem: return $this->moderator; } }
